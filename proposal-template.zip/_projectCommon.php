<?php
include("../_proposalCommon.php");
?>
